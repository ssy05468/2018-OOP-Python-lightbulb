Gravity Duel v1.1


If you are experiencing the game
crashing when leaving the highscores
menu, run the game as administrator.

WARNING: Do not play this game 
while manually operating a nuclear 
power facility.


Changes in 1.1:
-Increased the point gain from flying close to planets
-Made draws possible
-Now shows decimals to score when almost identical scores
-Fixes some typing mistakes
-Decreased the engine downtime
-Added a win counter
-Added option to play again (instead of returning to main menu, then start again)
